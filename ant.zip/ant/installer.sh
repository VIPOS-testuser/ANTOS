#!/bin/bash

# --- RANGAR VA LOGO ---
GREEN='\033[0;32m'
RED='\033[0;31m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

clear
echo -e "${CYAN}"
echo "  █████╗ ███╗   ██╗████████╗     ██████╗ ███████╗"
echo " ██╔══██╗████╗  ██║╚══██╔══╝    ██╔═══██╗██╔════╝"
echo " ███████║██╔██╗ ██║   ██║       ██║   ██║███████║"
echo " ██╔══██║██║╚██╗██║   ██║       ██║   ██║╚════██║"
echo " ██║  ██║██║ ╚████║   ██║       ╚██████╔╝███████║"
echo " ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝        ╚═════╝ ╚══════╝"
echo -e "          THE ULTIMATE INSTALLER v2.1${NC}\n"

# --- 1. DISKNI TANLASH ---
echo -e "${YELLOW}Mavjud disklar ro'yxati:${NC}"
lsblk -dno NAME,SIZE,MODEL | grep -v "loop" | awk '{print NR-1") /dev/"$1" - "$2" - "$3,$4,$5}'

while :; do
    echo -ne "\n${CYAN}O'rnatish uchun flashka raqamini tanlang: ${NC}"
    read DISK_IDX
    
    # Tanlangan diskni aniqlash
    DEVICE_NAME=$(lsblk -dno NAME | grep -v "loop" | sed -n "$((DISK_IDX+1))p")
    
    if [[ -n "$DEVICE_NAME" ]]; then
        SELECTED_DISK="/dev/$DEVICE_NAME"
        break
    else
        echo -e "${RED}Xato: Bunday raqamli disk yo'q! Qayta urinib ko'ring.${NC}"
    fi
done

# Fleshka nomini saqlab qolish (Zavod nomi)
ORIGINAL_NAME=$(lsblk -dno MODEL $SELECTED_DISK | awk '{print $1}' | head -c 11)
[ -z "$ORIGINAL_NAME" ] && ORIGINAL_NAME="ANTOS_USB"

# --- 2. MAXFIYLIK DARAJASI ---
echo -e "\n${YELLOW}Maxfiylik darajasini tanlang:${NC}"
echo "1) Ochiq (Hamma narsa bitta ochiq bo'limda)"
echo "2) Yarim-yashirin (Tizim yashirin, Data ochiq)"
echo "3) To'liq yashirin (Tizim va Skript yashirin)"
echo -ne "${CYAN}Tanlov (1-3): ${NC}"
read LEVEL

# --- 3. .sh FAYLINI SO'RASH ---
while :; do
    echo -ne "\n${YELLOW}Ishga tushiriladigan skript yo'lini kiriting (.sh): ${NC}"
    read USER_SH_PATH
    # ~ belgisini to'liq yo'lga aylantirish
    USER_SH_PATH="${USER_SH_PATH/#\~/$HOME}"
    
    if [[ -f "$USER_SH_PATH" ]]; then
        echo -e "${GREEN}Fayl tasdiqlandi.${NC}"
        break
    else
        echo -e "${RED}Xato: Fayl topilmadi! To'liq yo'lni kiriting.${NC}"
    fi
done

# --- 4. TIZIMNI TAYYORLASH ---
echo -e "\n${YELLOW}Tizim fayllari yig'ilmoqda...${NC}"
rm -rf /tmp/antos_rootfs
cp -r rootfs /tmp/antos_rootfs

# Init skriptiga skriptni chaqirish kodini qo'shish (exec bash dan oldin)
# Avval bor bo'lsa tozalash
sed -i '/# --- ANTOS_LOGIC ---/,/# --- END ---/d' /tmp/antos_rootfs/init

LOGIC_BLOCK="# --- ANTOS_LOGIC ---\nif [ -f /1.sh ]; then\n    /bin/bash /1.sh\nelif [ -f /mnt/data/1.sh ]; then\n    /bin/bash /mnt/data/1.sh\nfi\n# --- END ---"

# Bash ishga tushishidan oldin logikani joylashtirish
sed -i "/exec/i $LOGIC_BLOCK" /tmp/antos_rootfs/init

if [ "$LEVEL" == "3" ]; then
    cp "$USER_SH_PATH" /tmp/antos_rootfs/1.sh
    chmod +x /tmp/antos_rootfs/1.sh
fi

# Initramfs yig'ish
(cd /tmp/antos_rootfs && find . | cpio -o -H newc | gzip > /tmp/initramfs.cpio.gz)

# --- 5. DISKNI FORMATLASH ---
echo -e "${RED}Formatlanmoqda: $SELECTED_DISK...${NC}"
# Barcha ulanishlarni uzish
umount ${SELECTED_DISK}* 2>/dev/null || true

if [ "$LEVEL" == "1" ]; then
    parted -s $SELECTED_DISK mklabel msdos mkpart primary fat32 1MiB 100%
    sleep 1
    mkfs.vfat -n "$ORIGINAL_NAME" ${SELECTED_DISK}1
else
    parted -s $SELECTED_DISK mklabel msdos \
        mkpart primary fat32 1MiB 101MiB \
        mkpart primary fat32 101MiB 100%
    parted -s $SELECTED_DISK set 1 boot on
    sleep 1
    mkfs.vfat -n "ANTOS_BOOT" ${SELECTED_DISK}1
    mkfs.vfat -n "$ORIGINAL_NAME" ${SELECTED_DISK}2
fi

# --- 6. FAYLLARNI YOZISH ---
mkdir -p /mnt/antos_boot
mount ${SELECTED_DISK}1 /mnt/antos_boot

mkdir -p /mnt/antos_boot/boot/grub
cp vmlinuz /mnt/antos_boot/boot/
cp /tmp/initramfs.cpio.gz /mnt/antos_boot/boot/

# GRUB-ni o'rnatish
echo -e "${YELLOW}GRUB yuklovchisi o'rnatilmoqda...${NC}"
grub-install --target=i386-pc --boot-directory=/mnt/antos_boot/boot --modules="part_msdos fat" $SELECTED_DISK

# GRUB Config
cat <<EOF > /mnt/antos_boot/boot/grub/grub.cfg
set default=0
set timeout=3
set root=(hd0,msdos1)

menuentry "ANT OS [ $ORIGINAL_NAME ]" {
    linux /boot/vmlinuz quiet loglevel=3 rdinit=/init
    initrd /boot/initramfs.cpio.gz
}
EOF

# 2-daraja uchun skriptni ochiq qismga nusxalash
if [ "$LEVEL" == "2" ]; then
    mkdir -p /mnt/antos_data
    mount ${SELECTED_DISK}2 /mnt/antos_data
    cp "$USER_SH_PATH" /mnt/antos_data/1.sh
    chmod +x /mnt/antos_data/1.sh
    umount /mnt/antos_data
fi

umount /mnt/antos_boot
echo -e "\n${GREEN}MUVAFFAQIYATLI YAKUNLANDI!${NC}"
echo -e "${CYAN}Fleshkangizni endi boot qilib ko'rishingiz mumkin.${NC}"
